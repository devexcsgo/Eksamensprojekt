using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GPRoser.Pages.Products
{
    public class CreateModel : CreatePageModel<Product>
    {
        public CreateModel(IProductDataService dataService)
            : base(dataService)
        {
        }
    }
}
