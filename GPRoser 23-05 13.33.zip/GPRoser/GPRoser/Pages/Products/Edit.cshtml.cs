using Gadstrup_Rosenplanteskole.Models.Generated;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Threading.Tasks;

namespace GPRoser.Pages.Products
{
    public class EditModel : EditPageModel<Product>
    {
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly silasstilling_dk_db_gproserContext _context;

        public EditModel(IProductDataService dataService, IWebHostEnvironment webHostEnvironment, silasstilling_dk_db_gproserContext context)
            : base(dataService)
        {
            _webHostEnvironment = webHostEnvironment;
            _context = context;

            Colors = new SelectList(Enumerable.Empty<RoseColor>(), "Id", "Name");
            Types = new SelectList(Enumerable.Empty<RoseType>(), "Id", "Name");
        }

        public SelectList Colors { get; set; }
        public SelectList Types { get; set; }

        public override IActionResult OnGet(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = _dataService.Read(id);
            if (product == null)
            {
                return NotFound();
            }

            Data = product;

            Colors = new SelectList(_context.RoseColors.OrderBy(c => c.Name), "Id", "Name");
            Types = new SelectList(_context.RoseTypes.OrderBy(t => t.Name), "Id", "Name");

            return Page();
        }

        public override async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                Colors = new SelectList(_context.RoseColors.OrderBy(c => c.Name), "Id", "Name");
                Types = new SelectList(_context.RoseTypes.OrderBy(t => t.Name), "Id", "Name");

                return Page();
            }

            var existingProduct = _dataService.Read(Data.Id);

            if (existingProduct == null)
            {
                return NotFound();
            }

            if (Data.ImageFile != null)
            {
                var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");
                var uniqueFileName = Guid.NewGuid().ToString() + "_" + Data.ImageFile.FileName;
                var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await Data.ImageFile.CopyToAsync(fileStream);
                }
                Data.ImagePath = "/uploads/" + uniqueFileName;

                // Optional: Delete old image file
                if (!string.IsNullOrEmpty(existingProduct.ImagePath))
                {
                    var oldFilePath = Path.Combine(_webHostEnvironment.WebRootPath, existingProduct.ImagePath.TrimStart('/'));
                    if (System.IO.File.Exists(oldFilePath))
                    {
                        System.IO.File.Delete(oldFilePath);
                    }
                }
            }
            else
            {
                Data.ImagePath = existingProduct.ImagePath;
            }

            _dataService.Update(Data.Id, Data);

            return RedirectToPage(_onPostRedirectPage);
        }
    }
}
