﻿public interface IHasId
{
    int Id { get; set; }
}

