using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GPRoser.Pages.Admin
{
    public class CreateUserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
