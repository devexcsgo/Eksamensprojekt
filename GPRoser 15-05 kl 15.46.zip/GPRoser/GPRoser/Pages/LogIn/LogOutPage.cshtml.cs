using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GPRoser.Pages.LogIn
{
    public class LogOutPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
