using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
#nullable disable


namespace GPRoser.Pages.LogIn
{
	public class LogInPageModel : PageModel
	{
		private IUserDataService _userDataService;

		public static User LoggedInUser { get; set; }

		[BindProperty]
		public string UserName { get; set; }

		[BindProperty, DataType(DataType.Password)]
		public string Password { get; set; }

		public string Message { get; set; }
	}
}
