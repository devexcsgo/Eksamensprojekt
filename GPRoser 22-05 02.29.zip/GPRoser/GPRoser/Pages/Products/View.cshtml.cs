using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GPRoser.Pages.Products
{
    public class ViewModel : ViewPageModel<Product>
    {
        public ViewModel(IProductDataService dataService) 
            : base(dataService) 
        { 
        }
    }
}
