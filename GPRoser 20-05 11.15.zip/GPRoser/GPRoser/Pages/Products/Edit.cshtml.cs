using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GPRoser.Pages.Products
{
    public class EditModel : EditPageModel<Product>
    {
    public EditModel(IProductDataService dataService): base(dataService) 
        {
        }    
    }
}
