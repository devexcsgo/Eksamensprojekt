CREATE TABLE [dbo].[Customer] (
    [Id]      INT            IDENTITY (1, 1) NOT NULL,
    [Name]    NVARCHAR (MAX) NOT NULL,
    [Email]   NVARCHAR (MAX) NOT NULL,
    [Address] NVARCHAR (MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO

CREATE TABLE [dbo].[Product] (
    [Id]        INT            IDENTITY (1, 1) NOT NULL,
    [Name]      NVARCHAR (MAX) NOT NULL,
    [Price]     FLOAT (53)     NOT NULL,
    [ImagePath] NVARCHAR (MAX) NULL,
    [colorId]   INT            NULL,
    [typeId]    INT            NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Product_RoseColor] FOREIGN KEY ([colorId]) REFERENCES [dbo].[RoseColor] ([Id]),
    CONSTRAINT [FK_Product_RoseType] FOREIGN KEY ([typeId]) REFERENCES [dbo].[RoseType] ([Id])
);

GO

CREATE TABLE [dbo].[Order] (
    [Id]         INT IDENTITY (1, 1) NOT NULL,
    [CustomerId] INT NOT NULL,
    [ProductId]  INT NOT NULL,
    [Amount]     INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Order_Customer_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [dbo].[Customer] ([Id]),
    CONSTRAINT [FK_Order_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [dbo].[Product] ([Id])
);

GO

CREATE TABLE [dbo].[User] (
    [Id]       INT            IDENTITY (1, 1) NOT NULL,
    [UserName] NVARCHAR (MAX) NOT NULL,
    [Password] NVARCHAR (MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

GO

CREATE TABLE [dbo].[RoseColor] (
    [Id]   INT           NOT NULL,
    [Name] NVARCHAR (40) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

GO

CREATE TABLE [dbo].[RoseType] (
    [Id]   INT           NOT NULL,
    [Name] NVARCHAR (40) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

GO




