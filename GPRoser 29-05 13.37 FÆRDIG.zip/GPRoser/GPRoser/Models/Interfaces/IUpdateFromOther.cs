﻿//Hovedansvar alle
public interface IUpdateFromOther<T>
{
    void Update(T tOther);
}
