﻿//Hovedansvar alle
public interface IHasId
{
    int Id { get; set; }
}

