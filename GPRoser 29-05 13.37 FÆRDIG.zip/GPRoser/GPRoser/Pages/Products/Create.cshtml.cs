//Hovedansvar Alle
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Gadstrup_Rosenplanteskole.Models.Generated;

namespace GPRoser.Pages.Products
{
    public class CreateModel : CreatePageModel<Product>
    {
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly silasstilling_dk_db_gproserContext _context;

        public CreateModel(IProductDataService dataService, IWebHostEnvironment webHostEnvironment, silasstilling_dk_db_gproserContext context)
            : base(dataService)
        {
            _webHostEnvironment = webHostEnvironment;
            _context = context;

            Colors = new SelectList(Enumerable.Empty<RoseColor>(), "Id", "Name");
            Types = new SelectList(Enumerable.Empty<RoseType>(), "Id", "Name");
        }

        public SelectList Colors { get; set; }
        public SelectList Types { get; set; }


		public override IActionResult OnGet()
        {
            Colors = new SelectList(_context.RoseColors.OrderBy(c => c.Name), "Id", "Name");
            Types = new SelectList(_context.RoseTypes.OrderBy(t => t.Name), "Id", "Name");

            return Page();
        }

        public override async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                Colors = new SelectList(_context.RoseColors.OrderBy(c => c.Name), "Id", "Name");
                Types = new SelectList(_context.RoseTypes.OrderBy(t => t.Name), "Id", "Name");

                return Page();
            }

            if (Data.ImageFile != null)
            {
                var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");
                var uniqueFileName = Guid.NewGuid().ToString() + "_" + Data.ImageFile.FileName;
                var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await Data.ImageFile.CopyToAsync(fileStream);
                }
                Data.ImagePath = "/uploads/" + uniqueFileName;
            }

			// Rosen bkiver skabt, vis den kan dannes uden problemmer,
			// derefter tilbagesender den Adminen tilbage til den Rose siden.
			_dataService.Create(Data);
            return RedirectToPage(_onPostRedirectPage);
        }
    }
}