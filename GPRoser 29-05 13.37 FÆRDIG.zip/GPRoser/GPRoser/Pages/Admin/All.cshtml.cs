using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
//Hovedansvar alle
namespace GPRoser.Pages.Admin
{
    public class AllModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
