﻿using Microsoft.AspNetCore.Mvc;
// Silas
public class CreatePageModel<T> : PageModelAppBase<T>
    where T : class, IHasId, IUpdateFromOther<T>, new()
{
    public CreatePageModel(IDataService<T> dataService, string onPostRedirectPage = DefaultRedirectPage)
        : base(dataService, onPostRedirectPage)
    {
    }

    public virtual IActionResult OnGet()
    {
        return Page();
    }

    public virtual async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }
        _dataService.Create(Data);

        return RedirectToPage(_onPostRedirectPage);
    }
}
