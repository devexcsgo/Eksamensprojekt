﻿using Microsoft.AspNetCore.Mvc;
// Silas
public class EditPageModel<T> : PageModelExistingData<T>
    where T : class, IHasId, IUpdateFromOther<T>, new()
{
    public EditPageModel(IDataService<T> dataService, string onPostRedirectPage = DefaultRedirectPage)
        : base(dataService, onPostRedirectPage)
    {
    }


    public virtual async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }
        _dataService.Update(Data.Id, Data);

        return RedirectToPage(_onPostRedirectPage);
    }
}
