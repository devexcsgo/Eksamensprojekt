﻿//Hovedansvar: Alle
using Gadstrup_Rosenplanteskole.Models.Generated;
using Microsoft.EntityFrameworkCore;


/// <summary>
/// Application-specific base class for an Entity Framework Core-based data service implementation.
/// </summary>
/// <typeparam name="TData">Type of entities being managed</typeparam>
public class EFCDataServiceAppBase<T> : EFCDataServiceBase<T> where T : class, IHasId, IUpdateFromOther<T>
{

    protected override DbContext CreateDBContext() => new silasstilling_dk_db_gproserContext();
}
