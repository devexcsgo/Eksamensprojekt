﻿//Hovedansvar: Alle
public interface IUserDataService : IDataService<User>
{
	/// <summary>
	/// verificerer at den givne brugers brugernavn og adgangskode passer med en en profil i databasen. 
	/// </summary>
	/// <returns>User matching the provided information, otherwise null.</returns>
	User? VerifyUser(string providedUserName, string providedPassword);
}
