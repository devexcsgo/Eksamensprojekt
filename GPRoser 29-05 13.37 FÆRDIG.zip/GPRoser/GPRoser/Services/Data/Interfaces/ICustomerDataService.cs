﻿//Hovedansvar: Alle
public interface ICustomerDataService : IDataService<Customer>
{
}
