﻿//Hovedansvar: Alle
public interface IOrderDataService : IDataService<Order>
{
}
