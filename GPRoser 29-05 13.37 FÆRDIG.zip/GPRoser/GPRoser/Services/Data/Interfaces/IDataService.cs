﻿//Hovedansvar: Alle
/// <summary>
/// Technology-neutral interface for a data service, which offers
/// methods for managing entities of type TData.
/// </summary>
/// <typeparam name="TData">Type of entities being managed</typeparam>
public interface IDataService<TData> where TData : class, IHasId, IUpdateFromOther<TData>
{
	// Retunere alle entities gemt i data service.
	List<TData> GetAll();

	/// <summary>
	/// Gemmer den givne entity i data service, og tildeler også et nyt Id til entitien.
	/// Id'en bliver genereret og tildelt af data service.
	/// </summary>
	/// <returns>Id for the stored entity.</returns>
	int Create(TData t);

	/// <summary>
	/// Læser entitien med den givne Id.
	/// </summary>
	/// <returns>Entity with the given Id, if such an entity exists. Otherwise null.</returns>
	TData? Read(int id);

	/// <summary>
	/// Updatere entitien med den given Id.
	/// </summary>
	/// <returns>True if an entity was updated, otherwise false</returns>
	bool Update(int id, TData t);

	/// <summary>
	/// Sletter entitien med den givne Id.
	/// </summary>
	/// <returns>True if an entity was deleted, otherwise false</returns>
	bool Delete(int id);
}
