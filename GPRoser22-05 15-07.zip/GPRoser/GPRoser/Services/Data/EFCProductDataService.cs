﻿using Gadstrup_Rosenplanteskole.Models.Generated;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;


public class EFCProductDataService : EFCDataServiceAppBase<Product>, IProductDataService
{
    private readonly silasstilling_dk_db_gproserContext _context;

    public EFCProductDataService(silasstilling_dk_db_gproserContext context)
    {
        _context = context;
    }


    protected override IQueryable<Product> GetAllWithIncludes(DbContext context)
    {
        return context.Set<Product>()
            .Include(c => c.Orders)
            .Include(c => c.Color)
            .Include(c => c.Type);
    }


    // Brugte Lambda udtryk til filteringsystem
    public List<Product>MatchingFilters(int[] colorIds, int[] typeIds)
    {
        var query = GetAllWithIncludes(_context);

        if (colorIds != null && colorIds.Any())
        {
            query = query.Where(p => colorIds.Contains(p.ColorId.Value));
        }

        if (typeIds != null && typeIds.Any())
        {
            query = query.Where(p => typeIds.Contains(p.TypeId.Value));
        }

        return query.ToList();
    }

    public IEnumerable<RoseColor> GetColors()
    {
        return _context.RoseColors.ToList();
    }

    public IEnumerable<RoseType> GetTypes()
    {
        return _context.RoseTypes.ToList();
    }
}