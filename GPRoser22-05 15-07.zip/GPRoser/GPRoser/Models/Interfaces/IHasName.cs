﻿
public interface IHasName
{
    string Name { get; set; }
}
