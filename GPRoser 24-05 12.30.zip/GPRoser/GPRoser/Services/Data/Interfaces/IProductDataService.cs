﻿
public interface IProductDataService : IDataService<Product>
{
    //List<Product> GetAll();

    /// Forklaring: Denne kode returnere listen af Roser der passer til de valgte filter.
    /// 'Int'-ene bliver brugt som Arrays.
    List<Product> MatchingFilters(int[] colorIds, int[] typeIds); 
    IEnumerable<RoseColor> GetColors();
    IEnumerable<RoseType> GetTypes();
}