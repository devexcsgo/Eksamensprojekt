﻿
public interface ICustomerDataService : IDataService<Customer>
{
}
