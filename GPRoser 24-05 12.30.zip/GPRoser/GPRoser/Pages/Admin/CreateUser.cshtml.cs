using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace GPRoser.Pages.Admin
{
    [Authorize(Roles = "admin")]
    public class CreateUserModel : PageModel
    {
        private readonly IUserDataService _userDataService;
        private readonly PasswordHasher<string> _passwordHasher = new PasswordHasher<string>();

        public CreateUserModel(IUserDataService userDataService)
        {
            _userDataService = userDataService;
        }

        [BindProperty]
        public InputModel Data { get; set; }

        public class InputModel
        {
            [Required]
            [Display(Name = "User Name")]
            public string UserName { get; set; }

            [Required]
            [DataType(DataType.Password)]
            [Display(Name = "Password")]
            public string Password { get; set; }
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Koden der hasher brugerens adgangskode.
            var hashedPassword = _passwordHasher.HashPassword(Data.UserName, Data.Password);

            var user = new User
            {
                UserName = Data.UserName,
                Password = hashedPassword
            };

            _userDataService.Create(user);

            return RedirectToPage("/Index");
        }
    }
}
