using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GPRoser.Pages.Admin
{
    public class AllModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
