using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GPRoser.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
