﻿public interface IHasOrders
{
    ICollection<Order> Orders { get; set; }
    bool HasAnyOrders { get; }
}
