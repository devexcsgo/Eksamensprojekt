﻿public interface IUpdateFromOther<T>
{
    void Update(T tOther);
}
