﻿
public interface IOrderDataService : IDataService<Order>
{
}
