using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace GPRoser.Pages.Products
{
    public class AllModel : GetAllPageModel<Product>
    {
        private readonly IProductDataService _dataService;

        public AllModel(IProductDataService dataService)
            : base(dataService)
        {
            _dataService = dataService;
        }

        // Under dette er kode som st�tter filteringssystemet
        [BindProperty(SupportsGet = true)]
        public int[] SelectedColorIds { get; set; }
        [BindProperty(SupportsGet = true)]
        public int[] SelectedTypeIds { get; set; }

        public SelectList ColorSelectList { get; set; }
        public SelectList TypeSelectList { get; set; }

        public override void OnGet()
        {
            ColorSelectList = new SelectList(_dataService.GetColors(), "Id", "Name");
            TypeSelectList = new SelectList(_dataService.GetTypes(), "Id", "Name");

            if ((SelectedColorIds != null && SelectedColorIds.Any()) || (SelectedTypeIds != null && SelectedTypeIds.Any()))
            {
                Data = _dataService.MatchingFilters(SelectedColorIds, SelectedTypeIds);
            }
            else
            {
                Data = _dataService.GetAll().ToList();
            }
        }
    }
}