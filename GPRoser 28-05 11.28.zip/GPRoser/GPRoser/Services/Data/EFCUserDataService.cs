﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Linq;

// Implementering af User data service.
public class EFCUserDataService : EFCDataServiceAppBase<User>, IUserDataService
{
    public User? VerifyUser(string providedUserName, string providedPassword)
    {
        User? user = GetAll().FirstOrDefault(u => u.UserName == providedUserName);

        return user;
    }
}