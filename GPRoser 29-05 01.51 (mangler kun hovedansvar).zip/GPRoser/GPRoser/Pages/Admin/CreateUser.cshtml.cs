using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace GPRoser.Pages.Admin
{
    [Authorize(Roles = "admin")]
    public class CreateUserModel : CreatePageModel<User>
    {
        public CreateUserModel(IUserDataService userDataService)
            : base(userDataService, "/Index")
        {
        }
    }

}
