
CREATE TABLE [dbo].[Customer] (
    [Id]      INT            IDENTITY (1, 1) NOT NULL,
    [Name]    NVARCHAR (MAX) NOT NULL,
    [Email]   NVARCHAR (MAX) NOT NULL,
    [Address] NVARCHAR (MAX) NOT NULL
    PRIMARY KEY CLUSTERED ([Id] ASC)

);
GO

CREATE TABLE [dbo].[Product] (
    [Id]    INT            IDENTITY (1, 1) NOT NULL,
    [Name]  NVARCHAR (MAX) NOT NULL,
    [Price] FLOAT (53)     NOT NULL
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

GO

CREATE TABLE [dbo].[Order] (
    [Id]         INT           IDENTITY(1,1)  NOT NULL,
    [CustomerId] INT NOT NULL,
    [ProductId]  INT NOT NULL,
    [Amount]     INT NOT NULL
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Order_Customer_CustomerId] FOREIGN KEY ([CustomerId]) REFERENCES [dbo].[Customer] ([Id]),
    CONSTRAINT [FK_Order_Product_ProductId] FOREIGN KEY ([ProductId]) REFERENCES [dbo].[Product] ([Id])
);

GO

CREATE TABLE [dbo].[User] (
    [Id]       INT            IDENTITY (1, 1) NOT NULL,
    [UserName] NVARCHAR (MAX) NOT NULL,
    [Password] NVARCHAR (MAX) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

GO

INSERT INTO [dbo].[Product] ([Name], [Price]) VALUES (N'Heidi Klum Rose', 155)
INSERT INTO [dbo].[Product] ([Name], [Price]) VALUES (N'Penny Lane', 275)
INSERT INTO [dbo].[Product] ([Name], [Price]) VALUES (N'AbeTivoli', 450)
INSERT INTO [dbo].[Product] ([Name], [Price]) VALUES (N'Wide abek�d', 200)
INSERT INTO [dbo].[Product] ([Name], [Price]) VALUES (N'Inka', 69420)





