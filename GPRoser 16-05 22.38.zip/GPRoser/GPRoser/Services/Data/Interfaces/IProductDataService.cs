﻿
public interface IProductDataService : IDataService<Product>
{
}
