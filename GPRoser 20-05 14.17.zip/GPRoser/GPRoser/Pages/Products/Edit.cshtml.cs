using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.IO;
using System.Threading.Tasks;

namespace GPRoser.Pages.Products
{
    public class EditModel : EditPageModel<Product>
    {
        private readonly IWebHostEnvironment _webHostEnvironment;

        public EditModel(IProductDataService dataService, IWebHostEnvironment webHostEnvironment)
            : base(dataService)
        {
            _webHostEnvironment = webHostEnvironment;
        }

        public override async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var existingProduct = _dataService.Read(Data.Id);

            if (existingProduct == null)
            {
                return NotFound();
            }

            if (Data.ImageFile != null)
            {
                var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");
                var uniqueFileName = Guid.NewGuid().ToString() + "_" + Data.ImageFile.FileName;
                var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await Data.ImageFile.CopyToAsync(fileStream);
                }
                Data.ImagePath = "/uploads/" + uniqueFileName;

                // Optional: Delete old image file
                if (!string.IsNullOrEmpty(existingProduct.ImagePath))
                {
                    var oldFilePath = Path.Combine(_webHostEnvironment.WebRootPath, existingProduct.ImagePath.TrimStart('/'));
                    if (System.IO.File.Exists(oldFilePath))
                    {
                        System.IO.File.Delete(oldFilePath);
                    }
                }
            }
            else
            {
                Data.ImagePath = existingProduct.ImagePath;
            }

            _dataService.Update(Data.Id, Data);

            return RedirectToPage(_onPostRedirectPage);
        }
    }
}
