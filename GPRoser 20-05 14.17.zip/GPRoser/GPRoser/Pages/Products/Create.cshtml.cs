using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.IO;
using System.Threading.Tasks;

namespace GPRoser.Pages.Products
{
    public class CreateModel : CreatePageModel<Product>
    {
        private readonly IWebHostEnvironment _webHostEnvironment;

        public CreateModel(IProductDataService dataService, IWebHostEnvironment webHostEnvironment)
            : base(dataService)
        {
            _webHostEnvironment = webHostEnvironment;
        }

        public override async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            if (Data.ImageFile != null)
            {
                var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");
                var uniqueFileName = Guid.NewGuid().ToString() + "_" + Data.ImageFile.FileName;
                var filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await Data.ImageFile.CopyToAsync(fileStream);
                }
                Data.ImagePath = "/uploads/" + uniqueFileName;
            }

            _dataService.Create(Data);

            return RedirectToPage(_onPostRedirectPage);
        }
    }
}
